<?php
session_start();
include "koneksi.php";

if(isset($_POST['login'])){

    $username = $_POST['username'];
    $password = $_POST['password'];

    $cek = mysqli_query($conn,
    "SELECT * FROM admin
    WHERE username='$username'
    AND password='$password'");

    if(mysqli_num_rows($cek)>0){

        $_SESSION['login']=true;

        header("Location:index.php");
        exit;

    }else{

        $error="Username atau Password salah.";

    }

}
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Login MercuGuard</title>

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<div class="login-box">

<h1>🌊 MercuGuard</h1>

<h3>Login Admin</h3>

<form method="POST">

<input
type="text"
name="username"
placeholder="Username"
required>

<br><br>

<input
type="password"
name="password"
placeholder="Password"
required>

<br><br>

<button name="login">

LOGIN

</button>

</form>

<?php

if(isset($error)){

echo "<p style='color:red'>$error</p>";

}

?>

</div>

</body>

</html>
