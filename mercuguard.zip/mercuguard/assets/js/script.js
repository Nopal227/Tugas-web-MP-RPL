// ==============================
// MERCUGUARD JAVASCRIPT
// ==============================

document.addEventListener("DOMContentLoaded", function () {

    // ==========================
    // JAM DIGITAL
    // ==========================
    function updateClock() {

        const clock = document.getElementById("clock");

        if (!clock) return;

        const now = new Date();

        let h = now.getHours().toString().padStart(2, '0');
        let m = now.getMinutes().toString().padStart(2, '0');
        let s = now.getSeconds().toString().padStart(2, '0');

        clock.innerHTML = h + ":" + m + ":" + s;
    }

    setInterval(updateClock, 1000);
    updateClock();


    // ==========================
    // MENU AKTIF
    // ==========================

    let current = window.location.pathname.split("/").pop();

    let links = document.querySelectorAll(".sidebar a");

    links.forEach(function(link){

        let href = link.getAttribute("href");

        if(href === current){

            link.classList.add("active");

        }

    });


    // ==========================
    // ANIMASI CARD
    // ==========================

    let cards = document.querySelectorAll(".card");

    cards.forEach(function(card,index){

        card.style.opacity = "0";
        card.style.transform = "translateY(30px)";

        setTimeout(function(){

            card.style.transition = ".5s";

            card.style.opacity = "1";

            card.style.transform = "translateY(0)";

        },150 * index);

    });


    // ==========================
    // COUNTER ANIMATION
    // ==========================

    const counters = document.querySelectorAll(".counter");

    counters.forEach(counter=>{

        counter.innerText = "0";

        const update = ()=>{

            const target = Number(counter.getAttribute("data-target"));

            const c = Number(counter.innerText);

            const increment = Math.ceil(target/50);

            if(c < target){

                counter.innerText = c + increment;

                setTimeout(update,30);

            }else{

                counter.innerText = target;

            }

        }

        update();

    });

});


// ==============================
// KONFIRMASI LOGOUT
// ==============================

function logout(){

    let tanya = confirm("Yakin ingin logout?");

    if(tanya){

        window.location="logout.php";

    }

}


// ==============================
// ALERT STATUS
// ==============================

function statusInfo(text){

    alert(text);

}


// ==============================
// SCROLL KE ATAS
// ==============================

window.onscroll=function(){

    let btn=document.getElementById("topBtn");

    if(!btn) return;

    if(document.documentElement.scrollTop>200){

        btn.style.display="block";

    }else{

        btn.style.display="none";

    }

}

function topFunction(){

    window.scrollTo({

        top:0,

        behavior:"smooth"

    });

}
