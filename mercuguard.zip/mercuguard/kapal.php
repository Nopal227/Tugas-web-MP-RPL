<?php
session_start();

if(!isset($_SESSION['login'])){

header("Location:login.php");

exit;

}

include "koneksi.php";

$status="";

if(isset($_POST['cek'])){

$nama=$_POST['nama'];

$jarak=$_POST['jarak'];

if($jarak<1){

$status="🔴 BAHAYA";

}elseif($jarak<=3){

$status="🟡 WASPADA";

}else{

$status="🟢 AMAN";

}

mysqli_query($conn,"INSERT INTO kapal(nama_kapal,jarak,status)
VALUES('$nama','$jarak','$status')");

mysqli_query($conn,"INSERT INTO riwayat(fitur,hasil)
VALUES('Monitoring Kapal','$status')");

}

?>

<!DOCTYPE html>

<html>

<head>

<title>Monitoring Kapal</title>

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<?php include "sidebar.php"; ?>

<div class="content">

<h1>🚢 Monitoring Kapal</h1>

<div class="card">

<form method="POST">

<label>Nama Kapal</label>

<br><br>

<input
type="text"
name="nama"
required>

<br><br>

<label>Jarak Kapal (KM)</label>

<br><br>

<input
type="number"
step="0.1"
name="jarak"
required>

<br><br>

<button name="cek">

Analisa

</button>

</form>

</div>

<?php

if($status!=""){

echo "<div class='card'>";

echo "<h2>$status</h2>";

echo "</div>";

}

?>

</div>

<script src="assets/js/script.js"></script>

</body>

</html>
