<?php
session_start();

if(!isset($_SESSION['login'])){

header("Location:login.php");

exit;

}

include "koneksi.php";

$status = "";

if(isset($_POST['cek'])){

    $waktu = $_POST['waktu'];
    $cuaca = $_POST['cuaca'];

    if($waktu == "Malam" || $cuaca == "Berkabut"){

        $status = "Lampu MENYALA";

    }else{

        $status = "Lampu MATI";

    }

    mysqli_query($conn,"INSERT INTO lampu(waktu,cuaca,status)
    VALUES('$waktu','$cuaca','$status')");

    mysqli_query($conn,"INSERT INTO riwayat(fitur,hasil)
    VALUES('Lampu Mercusuar','$status')");
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Status Lampu</title>

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<div class="content">

<h1>💡 Status Lampu Mercusuar</h1>

<form method="POST">

<label>Waktu</label>

<br><br>

<select name="waktu">

<option>Siang</option>

<option>Malam</option>

</select>

<br><br>

<label>Cuaca</label>

<br><br>

<select name="cuaca">

<option>Cerah</option>

<option>Hujan</option>

<option>Berkabut</option>

</select>

<br><br>

<button name="cek">Cek Status</button>

</form>

<?php

if($status!=""){

echo "<div class='card'>";

echo "<h2>$status</h2>";

echo "</div>";

}

?>

</div>

</body>

</html>
