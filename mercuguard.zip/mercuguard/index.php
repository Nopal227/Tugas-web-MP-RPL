<?php
session_start();

if(!isset($_SESSION['login'])){

header("Location:login.php");

exit;

}

include "koneksi.php";
?>
<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>MercuGuard</title>

<link rel="stylesheet" href="assets/css/style.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

</head>

<body>

<?php include "sidebar.php"; ?>
<h2>🌊 MercuGuard</h2>

<div class="content">

<h1>Dashboard MercuGuard</h1>
<div id="clock" style="font-size:24px;font-weight:bold;"></div>
<div class="card">

<h2>Status Hari Ini</h2>

<p>💡 Lampu : Standby</p>

<p>🚢 Kapal : Tidak ada laporan</p>

<p>🌊 Laut : Aman</p>

<p>⚡ Genset : Siaga</p>

<p>🔋 Baterai : 100%</p>

</div>

</div>
<script src="assets/js/script.js"></script>
</body>
</html>
