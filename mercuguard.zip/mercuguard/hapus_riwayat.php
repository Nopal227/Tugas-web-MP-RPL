<?php

include "koneksi.php";

mysqli_query($conn,"TRUNCATE TABLE riwayat");

header("Location:riwayat.php");

?>
