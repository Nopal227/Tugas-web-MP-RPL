<?php
session_start();

if(!isset($_SESSION['login'])){

header("Location:login.php");

exit;

}

include "koneksi.php";
$status = "";
$warna = "#3ddc84";

if(isset($_POST['cek'])){

    $persen = $_POST['persen'];

    if($persen >= 80){

        $status = "🟢 Baterai Sangat Baik";
        $warna = "#3ddc84";

    }elseif($persen >= 50){

        $status = "🟡 Baterai Cukup";
        $warna = "#ffd54a";

    }elseif($persen >= 20){

        $status = "🟠 Baterai Lemah";
        $warna = "#ff9800";

    }else{

        $status = "🔴 Baterai Kritis";
        $warna = "#ff4d4d";

    }

    mysqli_query($conn,"INSERT INTO baterai(persen,status)
    VALUES('$persen','$status')");

    mysqli_query($conn,"INSERT INTO riwayat(fitur,hasil)
    VALUES('Monitoring Baterai','$status')");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">

<title>Monitoring Baterai</title>

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<?php include "sidebar.php"; ?>

<div class="content">

<h1>🔋 Monitoring Baterai</h1>

<div class="card">

<form method="POST">

<label>Persentase Baterai (%)</label>

<br><br>

<input
type="number"
name="persen"
min="0"
max="100"
required>

<br><br>

<button name="cek">

Cek Baterai

</button>

</form>

</div>

<?php

if($status!=""){

echo "

<div class='card'
style='border-left:8px solid $warna;'>

<h2>$status</h2>

<p>Persentase : <b>$persen%</b></p>

</div>

";

}

?>

</div>

<script src="assets/js/script.js"></script>

</body>

</html>
