<?php
session_start();

if(!isset($_SESSION['login'])){

header("Location:login.php");

exit;

}

include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<title>Riwayat Pemeriksaan</title>

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<?php include "sidebar.php"; ?>

<div class="content">

<h1>📋 Riwayat Pemeriksaan</h1>

<div class="card">
<a href="hapus_riwayat.php"
onclick="return confirm('Hapus semua riwayat?')">

<button>

🗑 Hapus Riwayat

</button>

</a>
<table>

<tr>

<th>No</th>

<th>Fitur</th>

<th>Hasil</th>

<th>Tanggal</th>

</tr>

<?php

$no=1;

while($d=mysqli_fetch_array($data)){

?>

<tr>

<td><?= $no++; ?></td>

<td><?= $d['fitur']; ?></td>

<td><?= $d['hasil']; ?></td>

<td><?= $d['tanggal']; ?></td>

</tr>

<?php } ?>

</table>

</div>

</div>

<script src="assets/js/script.js"></script>

</body>

</html>
