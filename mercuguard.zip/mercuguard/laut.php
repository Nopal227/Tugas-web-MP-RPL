<?php
session_start();

if(!isset($_SESSION['login'])){

header("Location:login.php");

exit;

}

include "koneksi.php";

$status="";

if(isset($_POST['cek'])){

    $gelombang=$_POST['gelombang'];
    $angin=$_POST['angin'];

    if($gelombang>=3 || $angin>=40){

        $status="🔴 BAHAYA";
        $warna="#ff4d4d";

    }elseif($gelombang>=1.5 || $angin>=20){

        $status="🟡 WASPADA";
        $warna="#ffd54a";

    }else{

        $status="🟢 AMAN";
        $warna="#3ddc84";

    }

    mysqli_query($conn,"INSERT INTO laut(gelombang,angin,status)
    VALUES('$gelombang','$angin','$status')");

    mysqli_query($conn,"INSERT INTO riwayat(fitur,hasil)
    VALUES('Kondisi Laut','$status')");
}
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<title>Kondisi Laut</title>

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<?php include "sidebar.php"; ?>

<div class="content">

<h1>🌊 Monitoring Kondisi Laut</h1>

<div class="card">

<form method="POST">

<label>Tinggi Gelombang (meter)</label>

<input
type="number"
step="0.1"
name="gelombang"
required>

<br><br>

<label>Kecepatan Angin (km/jam)</label>

<input
type="number"
name="angin"
required>

<br><br>

<button name="cek">

Analisa Kondisi

</button>

</form>

</div>

<?php

if($status!=""){

echo "

<div class='card'
style='border-left:8px solid $warna;'>

<h2>$status</h2>

<p>Tinggi Gelombang : $gelombang m</p>

<p>Kecepatan Angin : $angin km/jam</p>

</div>

";

}

?>

</div>

<script src="assets/js/script.js"></script>

</body>

</html>
