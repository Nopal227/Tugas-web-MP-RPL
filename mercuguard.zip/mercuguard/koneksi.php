<?php

$host = "127.0.0.1";
$user = "root";
$password = "";
$database = "mercuguard";

// Membuat koneksi
$conn = mysqli_connect($host, $user, $password, $database);

// Cek koneksi
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Mengatur timezone
date_default_timezone_set("Asia/Jakarta");

?>
