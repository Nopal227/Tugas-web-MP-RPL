<div class="sidebar">

    <h2>🌊 MercuGuard</h2>

    <a href="index.php">
        🏠 Dashboard
    </a>

    <a href="lampu.php">
        💡 Status Lampu
    </a>

    <a href="kapal.php">
        🚢 Monitoring Kapal
    </a>

    <a href="laut.php">
        🌊 Kondisi Laut
    </a>

    <a href="genset.php">
        ⚡ Genset
    </a>

    <a href="baterai.php">
        🔋 Baterai
    </a>

    <a href="riwayat.php">
        📋 Riwayat
    </a>

<a href="logout.php"
onclick="return confirm('Yakin ingin logout?')">

🚪 Logout

</a>
</div>
