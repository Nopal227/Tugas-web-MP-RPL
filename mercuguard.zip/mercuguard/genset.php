<?php
session_start();

if(!isset($_SESSION['login'])){

header("Location:login.php");

exit;

}

include "koneksi.php";

$status = "";
$warna = "#3ddc84";

if(isset($_POST['cek'])){

    $pln = $_POST['pln'];
    $bbm = $_POST['bbm'];

    if($pln == "Mati" && $bbm >= 20){

        $status = "🟢 Genset AKTIF";
        $warna = "#3ddc84";

    }elseif($pln == "Mati" && $bbm < 20){

        $status = "🔴 BBM HABIS - Bahaya";
        $warna = "#ff4d4d";

    }else{

        $status = "⚡ Menggunakan Listrik PLN";
        $warna = "#ffd54a";

    }

    mysqli_query($conn,"INSERT INTO genset(pln,bbm,status)
    VALUES('$pln','$bbm','$status')");

    mysqli_query($conn,"INSERT INTO riwayat(fitur,hasil)
    VALUES('Monitoring Genset','$status')");
}
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<title>Monitoring Genset</title>

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<?php include "sidebar.php"; ?>

<div class="content">

<h1>⚡ Monitoring Genset</h1>

<div class="card">

<form method="POST">

<label>Status PLN</label>

<br><br>

<select name="pln">

<option>Hidup</option>

<option>Mati</option>

</select>

<br><br>

<label>Sisa BBM (%)</label>

<br><br>

<input
type="number"
name="bbm"
min="0"
max="100"
required>

<br><br>

<button name="cek">

Cek Genset

</button>

</form>

</div>

<?php

if($status!=""){

echo "

<div class='card'
style='border-left:8px solid $warna;'>

<h2>$status</h2>

</div>

";

}

?>

</div>

<script src="assets/js/script.js"></script>

</body>

</html>
